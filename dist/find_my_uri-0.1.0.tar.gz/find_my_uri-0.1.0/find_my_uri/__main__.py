#!/usr/bin/env python3
"""
Entry point for running find_my_uri as a module.
"""

from find_my_uri.cli import main

if __name__ == "__main__":
    main()
